# Project 0
Blog style website
1. for Bootstrap task it is important to not forget include: <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
2. display: - this property specifies the display behavior of the element.
3. <span> tag is used to mark a part of text
4. border-collapse: - property sets whether table borders should collapse into a single border or be separated as in standard HTML.
5. padding: - is are used to generate space around an element's content, inside of any defined borders. 
Web Programming with Python and JavaScript
